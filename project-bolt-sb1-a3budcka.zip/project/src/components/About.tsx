import React from 'react';
import { MapPin, Award, Target, Users, TrendingUp, BarChart3, Zap } from 'lucide-react';

const About = () => {
  const locations = [
    { city: 'Rasipuram', region: 'Tamil Nadu' }
  ];

  const values = [
    {
      icon: Target,
      title: 'Results-Driven',
      description: 'Every strategy is designed with measurable outcomes and ROI in mind.'
    },
    {
      icon: Users,
      title: 'Client-Focused',
      description: 'Your success is our success. We build long-term partnerships, not just projects.'
    },
    {
      icon: Award,
      title: 'Quality First',
      description: 'We maintain the highest standards in every project, from design to deployment.'
    }
  ];

  return (
    <section id="about" className="py-24 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-orange-100 text-orange-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <span>About Us</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Driving Digital Success Since 2023
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Based in Tamil Nadu, we're a passionate team of digital marketing experts and web developers committed to helping businesses thrive in the digital landscape.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-6">Who We Are</h3>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Tamilan Digital Marketing is a results-driven digital marketing and web solutions agency that specializes in custom marketing strategies and modern web development. We're dedicated to delivering visibility, engagement, and growth for brands across diverse industries.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                With experience serving 80+ businesses, we combine creativity with data-driven insights to create digital solutions that truly make a difference.
              </p>
            </div>

            {/* Locations */}
            <div>
              <h4 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                <MapPin className="w-5 h-5 mr-2 text-green-600" />
                Our Location
              </h4>
              <div className="grid grid-cols-1 gap-4">
                {locations.map((location, index) => (
                  <div key={index} className="bg-white rounded-lg p-4 border border-gray-200">
                    <div className="font-semibold text-gray-900">{location.city}</div>
                    <div className="text-gray-600 text-sm">{location.region}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Stats and Values */}
          <div className="space-y-8">
            {/* Stats */}
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl p-8 text-white relative overflow-hidden">
              {/* Animated Background Elements */}
              <div className="absolute top-4 right-4 w-16 h-16 border border-white/20 rounded-full animate-spin"></div>
              <div className="absolute bottom-4 left-4 w-12 h-12 border border-white/20 rounded-full animate-pulse"></div>
              
              <h4 className="text-2xl font-bold mb-6">Our Impact</h4>
              <div className="grid grid-cols-3 gap-4 relative z-10">
                <div className="text-center group">
                  <div className="w-12 h-12 mx-auto mb-2 bg-white/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-3xl font-bold mb-2">80+</div>
                  <div className="text-sm opacity-90">Happy Clients</div>
                </div>
                <div className="text-center group">
                  <div className="w-12 h-12 mx-auto mb-2 bg-white/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-3xl font-bold mb-2">1.5+</div>
                  <div className="text-sm opacity-90">Years Experience</div>
                </div>
                <div className="text-center group">
                  <div className="w-12 h-12 mx-auto mb-2 bg-white/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-3xl font-bold mb-2">100%</div>
                  <div className="text-sm opacity-90">Client Satisfaction</div>
                </div>
              </div>
              
              {/* Performance Graph */}
              <div className="mt-6 bg-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium">Performance Growth</span>
                  <BarChart3 className="w-4 h-4" />
                </div>
                <div className="flex items-end space-x-2 h-8">
                  <div className="bg-white/30 w-4 h-4 rounded-t animate-pulse"></div>
                  <div className="bg-white/40 w-4 h-6 rounded-t animate-pulse" style={{animationDelay: '0.2s'}}></div>
                  <div className="bg-white/50 w-4 h-8 rounded-t animate-pulse" style={{animationDelay: '0.4s'}}></div>
                  <div className="bg-white/40 w-4 h-5 rounded-t animate-pulse" style={{animationDelay: '0.6s'}}></div>
                  <div className="bg-white/60 w-4 h-7 rounded-t animate-pulse" style={{animationDelay: '0.8s'}}></div>
                </div>
              </div>
            </div>

            {/* Values */}
            <div>
              <h4 className="text-2xl font-bold text-gray-900 mb-6">Our Values</h4>
              <div className="space-y-4">
                {values.map((value, index) => (
                  <div key={index} className="bg-white rounded-lg p-6 border border-gray-200 hover:shadow-lg transition-shadow">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg flex items-center justify-center flex-shrink-0">
                        <value.icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h5 className="font-bold text-gray-900 mb-2">{value.title}</h5>
                        <p className="text-gray-600 text-sm">{value.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;