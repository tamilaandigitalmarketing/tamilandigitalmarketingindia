import React from 'react';
import { Globe, Mail, Phone, MapPin, Facebook, Instagram, Linkedin, Twitter } from 'lucide-react';

const Footer = () => {
  const services = [
    'SEO Optimization',
    'Social Media Marketing',
    'Social Media Management',
    'Website Development',
    'E-commerce Solutions',
    'Poster & Ad Editing'
  ];

  const specializations = [
    'Mobile App Development',
    'Educational Marketing',
    'Real Estate Marketing',
    'AI-Powered Advertising',
    'Custom Software',
    'Cloud Hosting'
  ];

  const socialLinks = [
    { icon: Facebook, href: 'https://www.facebook.com/544075335466131?ref=pl_edit_xav_ig_profile_page_web', label: 'Facebook' },
    { icon: Instagram, href: 'https://www.instagram.com/tamilan_digital_marketer?utm_source=qr', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer */}
        <div className="grid lg:grid-cols-4 gap-8 py-16">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg flex items-center justify-center">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Tamilan Digital</h3>
                <p className="text-sm text-gray-400">Marketing</p>
              </div>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              Results-driven digital marketing and web solutions agency specializing in custom strategies that deliver visibility, engagement, and growth.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-green-600 transition-colors duration-200"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Digital Services</h4>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service}>
                  <a href="#services" className="text-gray-400 hover:text-white transition-colors duration-200">
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Specializations */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Specializations</h4>
            <ul className="space-y-3">
              {specializations.map((spec) => (
                <li key={spec}>
                  <a href="#specializations" className="text-gray-400 hover:text-white transition-colors duration-200">
                    {spec}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Get In Touch</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-green-500" />
                <span className="text-gray-400">tamilandigitalmarketing69@gmail.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-green-500" />
                <span className="text-gray-400">+91 6379532539</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-green-500 mt-1" />
                <div className="text-gray-400">
                  <div>Rasipuram, Tamil Nadu</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="border-t border-gray-800 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-gray-400 text-sm">
              © {new Date().getFullYear()} Tamilan Digital Marketing. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Cookie Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;