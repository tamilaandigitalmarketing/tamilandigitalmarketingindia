import React from 'react';
import { Heart, GraduationCap, Home, Brain, TrendingUp, BarChart3, Target, Zap } from 'lucide-react';

const Specializations = () => {
  const specializations = [
    {
      icon: Brain,
      title: 'AI-Powered Advertising',
      description: 'Leverage data and automation to run high-performance ads across OTT, YouTube, mobile, and web platforms.',
      features: ['Programmatic advertising', 'Data-driven campaigns', 'Multi-platform reach', 'Performance optimization'],
      color: 'from-purple-500 to-indigo-600',
      bgColor: 'bg-purple-50'
    },
    {
      icon: GraduationCap,
      title: 'Educational Marketing',
      description: 'Generate leads and improve online presence with education-focused digital campaigns and solutions.',
      features: ['Student acquisition', 'Course promotion', 'Educational content', 'Lead generation'],
      color: 'from-blue-500 to-cyan-600',
      bgColor: 'bg-blue-50'
    },
    {
      icon: Home,
      title: 'Real Estate Marketing',
      description: 'Specialized marketing strategies for property developers, agents, and real estate businesses.',
      features: ['Property showcase', 'Lead generation', 'Virtual tours', 'Market analysis'],
      color: 'from-green-500 to-emerald-600',
      bgColor: 'bg-green-50'
    }
  ];

  return (
    <section id="specializations" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <span>Industry Expertise</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Specialized Solutions
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We bring deep industry knowledge and tailored strategies to help businesses in specific sectors achieve exceptional results.
          </p>
        </div>

        {/* Specializations Grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {specializations.map((spec, index) => (
            <div
              key={spec.title}
              className={`${spec.bgColor} rounded-2xl p-8 hover:shadow-xl transition-all duration-300 group`}
            >
              <div className="flex items-start space-x-4">
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${spec.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                  <spec.icon className="w-8 h-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">
                    {spec.title}
                  </h3>
                  <p className="text-gray-700 mb-6 leading-relaxed">
                    {spec.description}
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {spec.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full"></div>
                        <span className="text-sm text-gray-700 font-medium">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Services */}
        <div className="mt-16 bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 text-white">
          <div className="relative">
            {/* Performance Dashboard Visualization */}
            <div className="mb-8 text-center">
              <h3 className="text-2xl font-bold mb-6">Performance Dashboard</h3>
              <div className="grid grid-cols-4 gap-6 max-w-4xl mx-auto">
                <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-lg p-4 border border-blue-500/30">
                  <div className="w-12 h-12 mx-auto mb-3 bg-blue-500/30 rounded-full flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-blue-400" />
                  </div>
                  <div className="text-2xl font-bold text-blue-400">↗ 85%</div>
                  <div className="text-xs text-gray-300">Traffic Growth</div>
                </div>
                <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-lg p-4 border border-green-500/30">
                  <div className="w-12 h-12 mx-auto mb-3 bg-green-500/30 rounded-full flex items-center justify-center">
                    <Target className="w-6 h-6 text-green-400" />
                  </div>
                  <div className="text-2xl font-bold text-green-400">92%</div>
                  <div className="text-xs text-gray-300">Conversion Rate</div>
                </div>
                <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-lg p-4 border border-purple-500/30">
                  <div className="w-12 h-12 mx-auto mb-3 bg-purple-500/30 rounded-full flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-purple-400" />
                  </div>
                  <div className="text-2xl font-bold text-purple-400">4.8★</div>
                  <div className="text-xs text-gray-300">Client Rating</div>
                </div>
                <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 rounded-lg p-4 border border-orange-500/30">
                  <div className="w-12 h-12 mx-auto mb-3 bg-orange-500/30 rounded-full flex items-center justify-center">
                    <Zap className="w-6 h-6 text-orange-400" />
                  </div>
                  <div className="text-2xl font-bold text-orange-400">24h</div>
                  <div className="text-xs text-gray-300">Response Time</div>
                </div>
              </div>
            </div>
            
            <div className="grid lg:grid-cols-3 gap-8">
            <div>
              <h4 className="text-xl font-bold mb-4">Custom Software Solutions</h4>
              <p className="text-gray-300">Software tailored to your business processes, workflows, and automation needs.</p>
            </div>
            <div>
              <h4 className="text-xl font-bold mb-4">CMS & API Integrations</h4>
              <p className="text-gray-300">Seamless content management systems and third-party tool integrations for enhanced functionality.</p>
            </div>
            <div>
              <h4 className="text-xl font-bold mb-4">Social Media Advertising</h4>
              <p className="text-gray-300">Hyper-targeted ad campaigns across Facebook, Instagram, YouTube, LinkedIn, and Twitter.</p>
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Specializations;