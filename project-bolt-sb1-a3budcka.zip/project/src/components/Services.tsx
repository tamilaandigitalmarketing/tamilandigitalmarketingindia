import React from 'react';
import { Search, Share2, DollarSign, Star, FileText, Globe, Smartphone, Settings, Cloud, TrendingUp, BarChart3, Zap } from 'lucide-react';

const Services = () => {
  const digitalMarketingServices = [
    {
      icon: Search,
      title: 'SEO Optimization',
      description: 'Improve search engine visibility to drive relevant organic traffic and leads.',
      color: 'from-green-500 to-emerald-600'
    },
    {
      icon: Share2,
      title: 'Social Media Marketing',
      description: 'Build brand awareness and community engagement across Facebook, Instagram, and LinkedIn.',
      color: 'from-blue-500 to-cyan-600'
    },
    {
      icon: Share2,
      title: 'Social Media Management',
      description: 'Complete social media management including content creation, scheduling, and community engagement.',
      color: 'from-blue-500 to-purple-600'
    },
    {
      icon: Star,
      title: 'Reputation Management',
      description: 'Monitor, improve, and protect your brand\'s online reputation through strategic systems.',
      color: 'from-purple-500 to-pink-600'
    },
    {
      icon: DollarSign,
      title: 'Poster & Ad Editing',
      description: 'Professional graphic design services for social media posts, advertisements, and marketing materials.',
      color: 'from-orange-500 to-red-600'
    }
  ];

  const webServices = [
    {
      icon: Globe,
      title: 'Website Design & Development',
      description: 'Custom-built websites that are responsive, fast, and designed to convert.',
      color: 'from-indigo-500 to-blue-600'
    },
    {
      icon: Settings,
      title: 'E-commerce Development',
      description: 'Scalable and secure online stores with payment gateway integration and backend support.',
      color: 'from-green-500 to-teal-600'
    },
    {
      icon: Smartphone,
      title: 'Mobile App Development',
      description: 'Android and iOS apps for business needs, customer engagement, or operational efficiency.',
      color: 'from-pink-500 to-rose-600'
    },
    {
      icon: Cloud,
      title: 'Hosting & Maintenance',
      description: 'End-to-end support including domain setup, cloud hosting, backups, and security updates.',
      color: 'from-slate-500 to-gray-600'
    }
  ];

  const ServiceCard = ({ service, index }: { service: any, index: number }) => (
    <div 
      className="group bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className={`w-14 h-14 rounded-2xl bg-gradient-to-r ${service.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
        <service.icon className="w-7 h-7 text-white" />
      </div>
      <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-green-600 transition-colors">
        {service.title}
      </h3>
      <p className="text-gray-600 leading-relaxed">
        {service.description}
      </p>
    </div>
  );

  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <span>Our Expertise</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Comprehensive Digital Solutions
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From digital marketing strategies to custom web development, we provide end-to-end solutions that drive real results for your business.
          </p>
        </div>

        {/* Digital Marketing Services */}
        <div className="mb-20">
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">Digital Marketing Services</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {digitalMarketingServices.map((service, index) => (
              <ServiceCard key={service.title} service={service} index={index} />
            ))}
          </div>
        </div>

        {/* Web Development Services */}
        <div>
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">Web & Software Development</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {webServices.map((service, index) => (
              <ServiceCard key={service.title} service={service} index={index} />
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-20 text-center">
          <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl p-8 text-white relative overflow-hidden">
            {/* Animated Background Graphics */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-8 left-8 w-24 h-24 border-2 border-white rounded-full animate-spin"></div>
              <div className="absolute bottom-8 right-8 w-16 h-16 border-2 border-white rounded-full animate-bounce"></div>
              <div className="absolute top-1/2 left-1/4 w-8 h-8 bg-white rounded-full animate-pulse"></div>
              <div className="absolute top-1/3 right-1/3 w-12 h-12 bg-white rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
            </div>
            
            <div className="relative z-10">
              {/* Success Metrics Visualization */}
              <div className="flex justify-center mb-6">
                <div className="flex items-center space-x-8">
                  <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-2 bg-white/20 rounded-full flex items-center justify-center">
                      <TrendingUp className="w-8 h-8 text-white" />
                    </div>
                    <div className="text-2xl font-bold">300%</div>
                    <div className="text-sm opacity-90">Growth Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-2 bg-white/20 rounded-full flex items-center justify-center">
                      <BarChart3 className="w-8 h-8 text-white" />
                    </div>
                    <div className="text-2xl font-bold">95%</div>
                    <div className="text-sm opacity-90">Success Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-2 bg-white/20 rounded-full flex items-center justify-center">
                      <Zap className="w-8 h-8 text-white" />
                    </div>
                    <div className="text-2xl font-bold">24/7</div>
                    <div className="text-sm opacity-90">Support</div>
                  </div>
                </div>
              </div>
            </div>
            
            <h3 className="text-3xl font-bold mb-4">Ready to Transform Your Business?</h3>
            <p className="text-xl mb-8 opacity-90">Let's discuss how our services can help you achieve your goals.</p>
            <a
              href="#contact"
              className="inline-flex items-center bg-white text-green-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-all duration-200 hover:scale-105 shadow-lg"
            >
              Get Free Consultation
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;